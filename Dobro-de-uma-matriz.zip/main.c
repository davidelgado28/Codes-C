#include <stdio.h>

int main() {

    int linha, coluna;

    scanf("%d %d", &linha, &coluna);

    int valores[linha][coluna];

    for(int i=0; i<linha; i++){
        for(int j=0; j<coluna; j++){
            scanf("%d", &valores[i][j]);
        }
    }
    for(int i=0; i<linha; i++){
        for(int j=0; j<coluna; j++){
            printf("%d ", valores[i][j]*2);
        }
        printf("\n");
    }
    return 0;
}